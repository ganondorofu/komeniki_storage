import {themes as prismThemes} from 'prism-react-renderer';
import dotenv from 'dotenv';
dotenv.config();

/** @type {import('@docusaurus/types').Config} */
const config = {
  title: 'ootomonaiso blog',
  tagline: '大友内装(粒)の技術ブログ',
  favicon: 'img/favicon.ico',
  url: 'https://ootomonaiso.github.io',
  baseUrl: '/ootomonaiso_strage/',

  organizationName: 'ootomonaiso',
  projectName: 'ootomonaiso_strage',  

  onBrokenLinks: 'throw',
  onBrokenMarkdownLinks: 'warn',

  i18n: {
    defaultLocale: 'ja',
    locales: ['ja'],
  },

  presets: [
    [
      'classic',
      /** @type {import('@docusaurus/preset-classic').Options} */
      ({
        docs: {
          sidebarPath: './sidebars.js',
          editUrl:
            'https://github.com/facebook/docusaurus/tree/main/packages/create-docusaurus/templates/shared/',
        },
        blog: {
          showReadingTime: true,
          editUrl:
            'https://github.com/facebook/docusaurus/tree/main/packages/create-docusaurus/templates/shared/',
        },
        theme: {
          customCss: './src/css/custom.css',
        },
      }),
    ],
  ],
  plugins: [
      [
        '@docusaurus/plugin-content-docs',
        {
          id: 'network-docs',
          path: 'network-docs',
          routeBasePath: 'network-docs',
          sidebarPath: require.resolve('./sidebars.js'),
          editUrl: 'https://github.com/ootomonaiso/ootomonaiso_strage',
        },
      ],
      [
        '@docusaurus/plugin-content-docs',
        {
          id: 'it-gyoumu-docs',
          path: 'it-gyoumu-docs',
          routeBasePath: 'it-gyoumu-docs',
          sidebarPath: require.resolve('./sidebars.js'),
          editUrl: 'https://github.com/ootomonaiso/ootomonaiso_strage',
        },
      ],
      [
        '@docusaurus/plugin-content-docs',
        {
          id: 'yoshinashi-docs',
          path: 'yoshinashi-docs',
          routeBasePath: 'yoshinashi-docs',
          sidebarPath: require.resolve('./sidebars.js'),
          editUrl: 'https://github.com/ootomonaiso/ootomonaiso_strage',
        },
      ],
  ],

  themeConfig:
    /** @type {import('@docusaurus/preset-classic').ThemeConfig} */
    ({
      image: 'img/docusaurus-social-card.jpg',
      colorMode: {
        defaultMode: 'dark'
      },
      navbar: {
        title: 'ootomonaiso blog',
        logo: {
          alt: 'logo',
          src: 'img/logo.svg',
        },
        items: [
            {
              to: '/docs/intro',
              position: 'left',
              label: '自己紹介',
            },
            {
              to: '/blog',
              label: 'Blog', 
              position: 'left'
            },
            {
              to: '/network-docs/',
              position: 'left',
              label: 'NetWork',
            },
            {
              to: '/it-gyoumu-docs/intro',
              position: 'left',
              label: '業務用ITソフトウェア',
            },
            {
              to: '/yoshinashi-docs/',
              position: 'left',
              label: 'よしなしこと',
            },
          {
            href: 'https://github.com/ootomonaiso',
            label: 'GitHub',
            position: 'right',
          },
        ],
      },
      // algolia: {
      //   appId: process.env.DOCSEARCH_APP_ID,
      //   apiKey: process.env.DOCSEARCH_API_KEY,
      //   indexName: process.env.DOCSEARCH_INDEX_NAME,
      //   insights: true,
      //   debug: false,
      // },  

      footer: {
        style: 'dark',
        links: [
          {
            title: 'ドキュメント',
            items: [
                {
                  label: '自己紹介',
                  to: '/docs/intro',
                },
                {
                  label: 'NetWork',
                  to: '/network-docs/',
                },
                {
                  label: '業務用ITソフトウェア',
                  to: '/it-gyoumu-docs/intro',
                },
            ],
          },
          {
            title: 'SNSアカウント',
            items: [
              {
                label: 'Twitter',
                href: 'https://x.com/ootomonaiso',
              },
              {
                label: 'Bluesky',
                href: 'https://bsky.app/profile/ootomonaiso.bsky.social',
              },
            ],
          },
          {
            title: 'その他',
            items: [
              {
                label: 'Blog',
                to: '/blog',
              },
              {
                label: 'GitHub',
                href: 'https://github.com/ootomonaiso',
              },
            ],
          },
        ],
        copyright: ` © ${new Date().getFullYear()} 大友内装(粒)`,
      },
      prism: {
        theme: prismThemes.github,
        darkTheme: prismThemes.dracula,
      },
    }),
  customFields: {
    geminiApiKey: process.env.REACT_APP_GEMINI_API_KEY,
    supabaseUrl: process.env.REACT_APP_SUPABASE_URL,
    supabaseAnonKey: process.env.REACT_APP_SUPABASE_ANON_KEY,
  },
  clientModules: [
    require.resolve('./src/clientModules/chatWidget.js'),
  ],
};

export default config;
