---
sidebar_position: 4
description: R-Kgw1設定
---

# R-Kgw1の設定

## おしながき
- v6デフォルトルート
- v6 ACL
    - ksvのDNS、Web、エコー要求許可
    - R-kgw1へのエコー要求許可
    - それ以外はダメ