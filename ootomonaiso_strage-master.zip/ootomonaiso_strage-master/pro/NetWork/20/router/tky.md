---
sidebar_position: 3
description: R-Tky設定
---

# R-Tkyの設定

## おしながき
- v4のデフォルトルート
- NAT(static、dynamic)
- v4 ACL
    - 戻りトラフィック許可
    - tsvに対してDNS、Web、smtp許可
    - tsvへエコー要求許可
    - R-Tkyへエコー要求許可
    - それ以外は許可しない

