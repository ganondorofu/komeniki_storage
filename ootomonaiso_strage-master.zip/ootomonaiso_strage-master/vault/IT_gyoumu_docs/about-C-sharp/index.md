---
sidebar_position: 1
description: C#を書こう
---
# C#で業務用ITしよう
まずは環境構築から進めてください。