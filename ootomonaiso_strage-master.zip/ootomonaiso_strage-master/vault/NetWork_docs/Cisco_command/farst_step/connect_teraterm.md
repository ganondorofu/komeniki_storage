---
sidebar_position: 2
description: TeratermからCMLへアクセス
---

# Teratermを起動
![Teratermの起動](./img/1-1.png)

**ホスト**にIPアドレスを入力

![ログイン](./img/1-2.png)

CMLに入るので、ここではCMLのWebUIにログインするときのユーザー名とパスワードを使用すること。