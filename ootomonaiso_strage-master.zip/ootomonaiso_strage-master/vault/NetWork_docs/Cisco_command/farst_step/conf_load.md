---
sidebar_position: 4
description: コンフィグをロードする
---

# ルーターのコンフィグをロードする

![Teratarmの起動](./img/41.png)

コンフィグ見たいルーター押してCONFIGからFETCH

