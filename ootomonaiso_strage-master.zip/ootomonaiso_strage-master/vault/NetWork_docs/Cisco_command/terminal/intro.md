---
sidebar_position: 1
description: はじめに
---

# ターミナル設定関連のメモ書き