---
slug: first-post
title: 最初の投稿
authors: [ootomonaiso]
---

# 