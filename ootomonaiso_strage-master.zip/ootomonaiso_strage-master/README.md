# ootomonaiso_strage

俺の知識の殿堂

